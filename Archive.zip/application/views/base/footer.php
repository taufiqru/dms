<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Repositori PTBA Ver. 1.0
    </div>
    <!-- Default to the left -->
    <strong>PT Bukit Asam Tbk &copy; 2020</strong>
  </footer>