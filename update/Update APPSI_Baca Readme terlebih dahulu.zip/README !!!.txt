README !!!

Replace file/folder dengan yang baru. Folder/File yang mengalami perubahan hanya di Controller, View dan asset/upload (grocerycrud).


Alamat FTP : 10.100.180.10
User 	   : appsi
Password   : 7yKVh2eT

Keterangan : Hanya dapat di Akses melalui Koneksi Unsri menggunakan KABEL LAN DI
             INDRALAYA

