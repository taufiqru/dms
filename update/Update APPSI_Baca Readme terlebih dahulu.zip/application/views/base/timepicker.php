<!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url();?>theme/plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- bootstrap time picker -->
<script src="<?=base_url();?>theme/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script>
	$(function(){
		//Timepicker
    	$(".timepicker").timepicker({
      	showInputs: false
    	});
	})
</script>