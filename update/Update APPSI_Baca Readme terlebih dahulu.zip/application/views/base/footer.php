<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Fasilkom Unsri
    </div>
    <!-- Default to the left -->
    <strong>Jurusan SI Fasilkom Unsri &copy; 2017</strong>
  </footer>